import { Component, EventEmitter, Input, OnChanges, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-updatestock',
  templateUrl: './updatestock.component.html',
  styleUrls: ['./updatestock.component.css']
})
export class UpdatestockComponent implements OnInit, OnChanges {

 @Input() stock: any;
 @Input() productId: any;
 color = '';
 stockvalue:any; 
 @Output() stockValueChangedEvent = new EventEmitter();
  constructor() { }

  ngOnInit(): void {
  }
  ngOnChanges(){
    if(this.stock > 5){
      this.color = 'green';
    }
    else {
      this.color ='red';
    }
  }

  stockValueChanged(){
    
    this.stockValueChangedEvent.emit({id:this.productId,updatedStockvalue:this.stockvalue});
    this.stockvalue = undefined; 
  }

}
