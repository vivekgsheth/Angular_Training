import { Component, Input, OnChanges, OnInit, SimpleChange } from '@angular/core';
// const template = `
//   <h4>{{_greetMessage}}</h4>
// `
// const template = `
//   <h4>{{_name}}</h4>
// `

const template = `
<h2>{{count}}</h2>
<h2>Value Changed</h2>
<table>
 <tr *ngFor="let logs of changeLog ">
 <td>{{logs}}</td>
 </tr>
</table>

`
@Component({
    selector: 'app-grand-child',
    template: template
})
export class GrandChildComponent implements OnInit, OnChanges {

    @Input() count = 0; 
    changeLog: string[] =[];

    // _greetMessage: any;
    // @Input()
    // set greetMessage(message: string) {
    //     this._greetMessage = message +"Jacob";
    // }
    // get greetMessage() {
    //     return this._greetMessage;
    // }

    // _name: any;
    // @Input()
    // set Name(n: string) {
    //     if(n == ' '){
    //         this._name = "Jacob Default Name";
    //     }
    //     else {
    //         this._name = n; 
    //     }

    // }
    // get Name() {
    //     return this._name
    // }
    constructor() {

    }

    ngOnInit(): void {

    }
    ngOnChanges(changes: {[property:string]:SimpleChange}): void {
      let log : string []=[]; 
      for(let p in changes){
          let c = changes[p];
          console.log(c);
          let from = JSON.stringify(c.previousValue); 
          let to = JSON.stringify(c.currentValue); 
          log.push(`${p} has changed from ${from} to ${to}`); 
          // SEND THIS LOG TO SERVER THROUGH API 
      }
      this.changeLog.push(log.join(','));

    }


}