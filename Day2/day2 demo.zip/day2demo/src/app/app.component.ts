import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'day2demo';
  data = 99;
  childmessage: string = "I am passed from the parent to child";
  nameArray = ['foo', 'koo', ' ', 'loo', ' ', 'zoo'];
  fooData = {
    data: 99
  };
  products:any; 
  productToUpdate : any; 

  ngOnInit(){
    this.products = this.getProducts();
    console.log(this.products);
  }
  updatedata() {
    // this.fooData.data = this.fooData.data+1; 
    // this.data = this.data + 1; 
    // console.log(this.fooData.data);
    this.data = this.data + 1;
  }
  updateStock(data:any){
     console.log(data);
     this.productToUpdate = this.products.find( (p:any) => p.id === data.id)
     console.log(this.productToUpdate);
     this.productToUpdate.stock = this.productToUpdate.stock + data.updatedStockvalue;
  }

 

  greetParent(data: any): void {
    alert(data);
  }


  getProducts() {
    return [
      {
        'id': '1', 'title': 'Screw Driver',
        'price': 400, 'stock': 11
      },
      {
        'id': '2', 'title': 'Nut Volt', 'price':
          200, 'stock': 5
      },
      {
        'id': '3', 'title': 'Resistor', 'price':
          78, 'stock': 45
      },
      {
        'id': '4', 'title': 'Tractor', 'price':
          20000, 'stock': 1
      },
      {
        'id': '5', 'title': 'Roller', 'price': 62,
        'stock': 15
      },
    ];
  }
}
