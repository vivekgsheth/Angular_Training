import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Input, OnChanges, OnInit } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit, OnChanges {

  @Input() message :any;
  @Input() foo :any; 
  @Input() temp :any;
  constructor() { 
    console.log('constructor');
  }

  ngOnInit(): void {
   console.log('ngoninit');
  }

  ngOnChanges(){
   console.log('ngonchanges');

  }

}
