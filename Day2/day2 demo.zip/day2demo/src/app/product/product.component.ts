import { Component, OnInit, EventEmitter, Output} from '@angular/core';


@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  // @Output() greetEvent = new EventEmitter();
  constructor() { }

  ngOnInit(): void {
  }

  // greet():void{
  //   this.greetEvent.emit("Hello I am passed from child to parent");
  //   //alert("hello from child");
  // }

}
