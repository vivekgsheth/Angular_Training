export const environment = {
  production: true,
  baseapiurl :"produd.api"
};
