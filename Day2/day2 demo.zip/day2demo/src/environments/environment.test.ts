export const environment = {
    production: false,
    baseapiurl :"prodtest.api"
  };