import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  
  Counter1 = {
    count : 1
  } 
  _count = 1; 
  Counter: any;
  
  constructor(){

  }
  incCount(){
   this.Counter1.count = this.Counter1.count + 1; 
  // this.Counter = {
  //   count : this.Counter.count+1 
  // }
   console.log(this.Counter1.count);
   this.Counter.next({
     count : ++this._count
   })
  }

  ngOnInit(){
    // setInterval(()=>{
    //   this.count = this.count + 1; 
    //   console.log(this.count);
    // },10)
    this.Counter = new BehaviorSubject<any>({
      count:0
    })
  }
}
