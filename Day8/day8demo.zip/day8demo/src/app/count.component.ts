// import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Input, OnChanges, OnDestroy, OnInit } from "@angular/core";

// const template = `
//  <h3>Count in Child ={{count}} </h3>
// `
// @Component({
//     selector:'app-count',
//     template:template,
//     changeDetection:ChangeDetectionStrategy.OnPush
// })
// export class CountComponent implements OnInit, OnChanges, OnDestroy{

//     count :any; 
//     @Input() Counter : any ; 
//     countsubscription$ : any; 

//     constructor(private cd : ChangeDetectorRef){
        
//     }

//     ngOnInit():void{

//     }

//     ngOnChanges(){
//      this.countsubscription$ = this.Counter.subscribe(
//          (data :any) =>{
//          this.count = data.count;
//          console.log(this.count);
//          this.cd.markForCheck();
//          },
//          (error:any)=> console.log(error),
//          ()=> console.log('complete'))

//     }

//     ngOnDestroy(){
//         this.countsubscription$.unsubscribe();
//     }
// }


// async pipe implementaion 


// import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Input, OnChanges, OnDestroy, OnInit } from "@angular/core";
// import { Observable } from "rxjs";

// const template = `
// <div *ngIf="Counter|async ;let data">
// <h3>Count in Child88 ={{data?.count}} </h3>
// </div>
// `
// @Component({
//     selector:'app-count',
//     template:template,
//     changeDetection:ChangeDetectionStrategy.OnPush
// })
// export class CountComponent implements OnInit, OnChanges, OnDestroy{

//     @Input() Counter : Observable<any> ; 
//     constructor(){
//         this.Counter = new Observable<any>();
//     }

//     ngOnInit():void{

//     }

//     ngOnChanges(){

//     }

//     ngOnDestroy(){
//     }
// }

// deattaching the component


import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Input, OnChanges, OnDestroy, OnInit } from "@angular/core";
import { Observable } from "rxjs";

const template = `
<p>{{title}}</p>
<h3>Count in child = {{Counter.count}}</h3>
<button (click)='attachcd()'>Refresh</button>
`
@Component({
    selector:'app-count',
    template:template,
    changeDetection:ChangeDetectionStrategy.Default
})
export class CountComponent implements OnInit, OnChanges, OnDestroy{

    @Input() Counter :any; 
     title = "Detach component";
    constructor(private cd : ChangeDetectorRef){
     
        this.cd.detach();
    }

    ngOnInit():void{

    }

    ngOnChanges(){

    }

    attachcd(){
       // this.cd.reattach();
      // this.cd.markForCheck();
      this.cd.detectChanges();
      }

    ngOnDestroy(){
    }
}


