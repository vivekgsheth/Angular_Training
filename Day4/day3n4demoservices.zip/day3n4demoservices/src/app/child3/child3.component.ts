import { Component, OnInit } from '@angular/core';
import { LogService } from '../log.service';
import { UpdatedlogService } from '../updatedlog.service';

@Component({
  selector: 'app-child3',
  templateUrl: './child3.component.html',
  styleUrls: ['./child3.component.css']
})
export class Child3Component implements OnInit {

  constructor(private logService : UpdatedlogService) { }
  udata: string ; 

  ngOnInit(): void {
   
  }
  getData(){
    this.udata= this.logService.getLog("Child 3");
  }


}
