import { Injectable } from '@angular/core';
// 1000 lines of codes are written 
@Injectable()
export class LogService {

  constructor() { }

  getLog(name:string ){
    // getting log from sql server using API 1 
    // This is created in Jan 2021 
   return "Hello Logs " + name ; 
  }
}
