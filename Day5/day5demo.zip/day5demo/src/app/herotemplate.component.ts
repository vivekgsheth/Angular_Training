import { Component } from '@angular/core';
import { Hero } from './hero';



const template = `

<div class="form-group">
  <label for="name">Name</label>
  <input type="text" class="form-control" id="name"
         required
         [(ngModel)]="model.name" name="name">
</div>

<div class="form-group">
  <label for="alterEgo">Alter Ego</label>
  <input type="text"  class="form-control" id="alterEgo"
         [(ngModel)]="model.alterEgo" name="alterEgo">
</div>

<div class="form-group">
  <label for="power">Hero Power</label>
  <select class="form-control"  id="power"
          required
          [(ngModel)]="model.power" name="power">
    <option *ngFor="let pow of powers" [value]="pow">{{pow}}</option>
  </select>
</div>

`;

const style = `.ng-valid[required], .ng-valid.required  { border-left: 5px solid #42A948; /* green */}
  
  .ng-invalid:not(form)  {
    border-left: 5px solid #a94442; /* red */
  }`


@Component({
    selector:'app-hero',
    template: template,
    styles:[style]
})
export class HeroComponent {

    powers = ['Really Smart', 'Super Flexible',
    'Super Hot', 'Weather Changer'];

    model = new Hero(18, 'Dr IQ', this.powers[0], 'Chuck Overstreet');
    submitted = false;

    onSubmit() { this.submitted = true; }

}