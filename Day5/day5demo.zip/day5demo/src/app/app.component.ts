import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators, FormBuilder, AbstractControl, ValidatorFn } from '@angular/forms';

function ageRangeValidator(minAge: number, maxAge: number): ValidatorFn {

  return (control: AbstractControl): { [key: string]: boolean } | null => {

    if (control.value !== undefined && (isNaN(control.value) || control.value < minAge || control.value > maxAge)) {

      return { 'ageRange': true };
    }
    return null;
  }
}

// function ageRangeValidator(control : AbstractControl) : {[key:string]:boolean} | null{

//   if(control.value !== undefined && (isNaN(control.value) || control.value < minAge || control.value > maxAge)){

//     return {'ageRange':true}; 
//   }

//   return null; 
// }


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  loginForm: FormGroup;
  minAge = 65; 
  maxAge = 80; // this data can come from API 
  constructor(private fb: FormBuilder) {
    //  this.loginForm = new FormGroup({
    //      email : new FormControl(null,[Validators.required]),
    //      password : new FormControl(null,[Validators.required,Validators.maxLength(8)])
    //  });
  }
  ngOnInit() {

    // this is coming from the API 
    // means using the service 

    let loginFomConfig = {
      email: ["dhananjay@abc.om", [Validators.required]],
      password: ["password", [Validators.required, Validators.maxLength(8)]],
      age: [null, [ageRangeValidator(this.minAge,this.maxAge)]],
      phonenumber : [null],
      notification:['email']
    };

    // this.loginForm = this.fb.group({
    //   email: [null, [Validators.required]],
    //   password : [null,[Validators.required,Validators.maxLength(8)] ]
    // })

     this.loginForm = this.fb.group(loginFomConfig);
     this.formControlValueChanged();


  }

  loginUser() {
    console.log(this.loginForm.value);
    console.log(this.loginForm.status);
    // make an api call 
    // pass this uset information to the server 
    // add user 


  }

  formControlValueChanged(){
   const phonecontrol = this.loginForm.get('phonenumber');
   this.loginForm.get('notification')?.valueChanges.subscribe(
     data=>{
        
      if(data === 'phone'){
         phonecontrol?.setValidators([Validators.required]);
      }
      else if(data === 'email'){

        phonecontrol?.clearValidators();

      }
      phonecontrol?.updateValueAndValidity();

     }
   )

  }

}
