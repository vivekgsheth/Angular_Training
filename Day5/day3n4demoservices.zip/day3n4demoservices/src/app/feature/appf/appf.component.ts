import { Component, OnInit } from '@angular/core';
import { LogService } from 'src/app/log.service';

@Component({
  selector: 'app-appf',
  templateUrl: './appf.component.html',
  styleUrls: ['./appf.component.css']
})
export class AppfComponent implements OnInit {

  udata: string ;
  constructor(private logService : LogService) {

  }
  ngOnInit(): void {
    this.udata  = this.logService.getLog("Feature Module Component");
  }

}
