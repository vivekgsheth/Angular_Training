import { Injectable } from '@angular/core';

//console.log("I am included in the bundle");

@Injectable({
  providedIn:'platform'
})
export class AppService {

  private static count = 0; 
  counter = 0; 
  
  constructor() { 
    AppService.count = AppService.count + 1; 
    console.log('app service object ' + AppService.count);
  }

  getData(){
    this.counter = this.counter + 1; 
    //console.log(this.counter);
    return this.counter;
    
  }
}
