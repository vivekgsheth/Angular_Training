import { Component, OnInit } from '@angular/core';
import { AppService } from '../app.service';
import { LogService } from '../log.service';

@Component({
  selector: 'app-child1',
  templateUrl: './child1.component.html',
  styleUrls: ['./child1.component.css']
})
export class Child1Component implements OnInit {

  udata: string ;
  apiconfig:any;
  constructor(private logService : LogService) {

  }

  ngOnInit(): void {
    this.apiconfig = this.logService.getValue();
    this.udata  = this.logService.getLog("Child 1");
  }


}
