import { ErrorHandler, NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AppService } from './app.service';
import { Child1Component } from './child1/child1.component';
import { Child2Component } from './child2/child2.component';
import { LogService } from './log.service';
import { UpdatedlogService } from './updatedlog.service';
import { Child3Component } from './child3/child3.component';
import { GlobalerrorService } from './globalerror.service';
import { FeatureModule } from './feature/feature.module';
import { CustomersModule } from './customers/customers.module';
import { ApiConfig } from './apiconfig';
import { apiconfigvalue } from './apiconfig.value';

// const flag = true; // api any business logic 
// const getLog = () =>{
//   if(flag){
//     return new LogService; 
//   }
//   else 
//   {
//     return new UpdatedlogService;
//   }
// }


export const configValue : ApiConfig={
  EndPoint:'abc.com',
  Token:'1234445'
};

@NgModule({
  declarations: [
    AppComponent,
    Child1Component,
    Child2Component,
    Child3Component
  ],
  imports: [
    FeatureModule,
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  // providers: [LogService],
  // providers:[{provide:ErrorHandler,useClass:GlobalerrorService},
  //           //  {provide:LogService,useClass:UpdatedlogService},
  //            {provide:LogService,useClass:LogService},
  //            {provide:UpdatedlogService,useExisting:LogService}
  // ],
  providers:[
  {provide:apiconfigvalue,useValue:configValue}],
  bootstrap: [AppComponent]
})
export class AppModule { }
