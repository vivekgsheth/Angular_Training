import { Component, OnInit } from '@angular/core';
import { LogService } from '../log.service';

@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.css']
})
export class CustomersComponent implements OnInit {

  udata: string ;
  apiconfig:any;
  constructor(private logService : LogService) {

  }
  ngOnInit(): void {
    this.udata  = this.logService.getLog("Custmer");
    this.apiconfig = this.logService.getValue();
  }

}
