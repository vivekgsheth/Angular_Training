import { Inject, Injectable } from '@angular/core';
import { ApiConfig } from './apiconfig';
import { apiconfigvalue } from './apiconfig.value';
// 1000 lines of codes are written 
@Injectable({
  providedIn:'any'
})
export class LogService {

  private static objectcount = 0; 
  constructor(@Inject(apiconfigvalue) private config:ApiConfig) {
    LogService.objectcount = LogService.objectcount + 1; 
    console.log('logservice object = ' + LogService.objectcount);
   }

  getLog(name:string ){
    // getting log from sql server using API 1 
    // This is created in Jan 2021 
   return "Hello Logs " + name ; 
  }

  getValue(){
    return this.config;
  }
}
