import { Injectable } from '@angular/core';
// updated code in updated log service 
@Injectable()
export class UpdatedlogService {

  constructor() { }

  getLog(name:string ){
    // getting log from Oracle   using API 2 
    // This is created in Jan 2022
   return "Hello Updated Logs " + name ; 
  }
}
