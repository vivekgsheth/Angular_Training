import { Component, OnInit } from '@angular/core';
import { LogService } from '../log.service';

@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.css']
})
export class OrdersComponent implements OnInit {

 
  udata: string ;
  apiconfig:any;
  constructor(private logService : LogService) {

  }
  ngOnInit(): void {
    this.udata  = this.logService.getLog("Orders");
    this.apiconfig = this.logService.getValue();
  }

}
