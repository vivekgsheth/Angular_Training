import { ErrorHandler, Injectable } from '@angular/core';

@Injectable()
export class GlobalerrorService implements ErrorHandler {

  constructor() { }
  handleError(error: any): void{
  
    // send report to server 
    
    let a : any; 
    console.log(a.sort());
    console.log('this is my error');
    throw error; 
  }
}
