import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { switchMap } from 'rxjs/operators';
import { OrderService } from '../order.service';

@Component({
  selector: 'app-editorder',
  templateUrl: './editorder.component.html',
  styleUrls: ['./editorder.component.css']
})
export class EditorderComponent implements OnInit {

  orderId: any;
  order: any;
  orderForm: FormGroup ; 
  constructor(private orderservice: OrderService,private fb: FormBuilder, private routerstate: ActivatedRoute, private route: Router) { 
    this.orderForm = this.fb.group({
      Id:[],
      Title:[],
      Quantity:[],
      Message :[],
      City:[]
    }) 
  }
  ngOnInit() {
    this.routerstate.paramMap.pipe(
      switchMap((params: any) => {
        this.orderId = params.get('id');
        return this.orderservice.getOrderDetails(this.orderId)
      }
      )).subscribe(
        data => {
          console.log(data);
          this.order = data[0];
         this.orderForm.setValue(this.order);
        }
      )
  }

  updateOrder():void{
    console.log(this.orderForm.value)
  }

}
