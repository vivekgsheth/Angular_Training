import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class RouteguardService implements CanActivate {

  isAuthenticated = false; 
  constructor(public router: Router) { }
  canActivate(){
    if(this.isAuthenticated == false){
      this.router.navigate(['login']);
      return false;
    }
    else {
      return true; 
    }
     
  }
 
}
