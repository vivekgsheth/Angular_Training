import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { Order } from '../order';
import { OrderService } from '../order.service';

@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.css']
})
export class OrdersComponent implements OnInit, OnDestroy {

  orders: any;
  orderSubscription$ : any; 
  constructor(private orderservice : OrderService, private router: Router) {

   }

  ngOnInit(): void {
  
   this.orderSubscription$ = this.orderservice.getOrders().subscribe(
     data=>{this.orders = data},
     error=>console.log(error)
   )
  }
  navigateToOrderDetails(id:any){
    console.log(id);
    this.router.navigate(["/orders",id.trim()]);
  }
  navigateToEditOrder(id:any){
    console.log(id);
    this.router.navigate(["/edit",id.trim()]);
  }

  ngOnDestroy():void{
    this.orderSubscription$.unsubscribe();
  }

}
