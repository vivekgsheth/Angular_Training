import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import {catchError, tap} from 'rxjs/operators';
import { Order } from './order';

@Injectable({
  providedIn: 'root'
})
export class OrderService {

  ApiUrl = "http://localhost:8090/api/orders";

  constructor(private http : HttpClient) { }

  getOrders(): Observable<Order>{
    return this.http.get<Order>(this.ApiUrl).pipe(
      tap((data)=>console.log(data)),
      catchError(this.handleError)
    )
  }

  getOrderDetails(id:any){
    const orderdetailurl = this.ApiUrl +'/'+id; 
    console.log(orderdetailurl);
    return this.http.get<any>(orderdetailurl).pipe(
      tap((data)=>console.log(data)),
      catchError(this.handleError)
    )
    
  }

  AddOrder(order:any){
    const headers = { 'content-type': 'application/json'}  
    const body=JSON.stringify(order);
    console.log(body)
    return this.http.post(this.ApiUrl, body,{'headers':headers}).pipe(
      tap((data)=>console.log(data)),
      catchError(this.handleError)
    )
  }
  private handleError(error: any) {
    console.error(error);
    return throwError(error);
  }
}
