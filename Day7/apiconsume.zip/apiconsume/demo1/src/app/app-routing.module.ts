import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddorderComponent } from './addorder/addorder.component';
import { EditorderComponent } from './editorder/editorder.component';
import { LoginComponent } from './login/login.component';
import { OrderdetailsComponent } from './orderdetails/orderdetails.component';
import { OrdersComponent } from './orders/orders.component';
import { RouteguardService } from './routeguard.service';

const routes: Routes = [
  {path:'home',component:OrdersComponent},
  {path:'add',component:AddorderComponent, canActivate: [RouteguardService]},
  {path:'edit/:id',component:EditorderComponent,canActivate: [RouteguardService]},
  {path:'orders/:id',component:OrderdetailsComponent},
  {path:'login',component:LoginComponent},
  {path:'*',redirectTo:'home',pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
