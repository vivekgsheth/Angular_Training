export interface Order {
    Id: string; 
    Title:string; 
    Quantity : number; 
    Message : string; 
    City: string; 
}