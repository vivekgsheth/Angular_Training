import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Subscription } from 'rxjs';
import { OrderService } from '../order.service';

@Component({
  selector: 'app-addorder',
  templateUrl: './addorder.component.html',
  styleUrls: ['./addorder.component.css']
})
export class AddorderComponent implements OnInit {

  order:any;
  addOrderSubscription$: any; 
  constructor(private fb: FormBuilder, private orderService : OrderService) {
    this.order; 
   }

  ngOnInit(): void {

    this.order = this.fb.group({
      Id:[],
      Title:[],
      Quantity:[],
      Message :[],
      City:[]
    }) 
  }
  addOrder(){
    this.order.value['Id']= this.getRandomInt(5000);
    console.log(this.order.value);
    this.addOrderSubscription$ = this.orderService.AddOrder(this.order.value).subscribe(
      data=> console.log(data),
      error => console.log(error)
    )
  }

   getRandomInt(max:any) {
    return Math.floor(Math.random() * Math.floor(max));
  }

}
