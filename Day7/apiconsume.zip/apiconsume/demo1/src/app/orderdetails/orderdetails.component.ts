import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap, Router, RouterState } from '@angular/router';
import { switchMap } from 'rxjs/operators';
import { OrderService } from '../order.service';

@Component({
  selector: 'app-orderdetails',
  templateUrl: './orderdetails.component.html',
  styleUrls: ['./orderdetails.component.css']
})
export class OrderdetailsComponent implements OnInit {

  orderId: any;
  order: any;
  constructor(private orderservice: OrderService,private router: Router, private routerstate: ActivatedRoute, private route: Router) { }

  ngOnInit(): void {

    // this.routerstate.paramMap.subscribe(params => {
    //  this.orderId = params.get('id');
    //  console.log(this.orderId);
    //  this.orderservice.getOrderDetails(this.orderId).subscribe(
    //    data=>{
    //      console.log(data);
    //      this.order = data; 
    //     }
    //  )
    // })

    this.routerstate.paramMap.pipe(
      switchMap((params: any) => {
        this.orderId = params.get('id');
        return this.orderservice.getOrderDetails(this.orderId)
      }
      )).subscribe(
        data => {
          console.log(data);
          this.order = data[0];
        }
      )

    // this.courseId = this.routerstate.snapshot.paramMap.get('id'); 
    // console.log(this.courseId);
  }

  navigateToEditOrder(id:any){
    console.log(id);
    this.router.navigate(["/edit",id.trim()]);
  }

}
