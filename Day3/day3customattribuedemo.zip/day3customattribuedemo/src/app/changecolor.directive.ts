import { Directive, ElementRef, HostBinding, HostListener, Input, Renderer2 } from '@angular/core';

@Directive({
  selector: '[appChangecolor]',
  exportAs:'foo'
})
export class ChangecolorDirective {

  @Input() color: any; 
  @HostBinding('style.border') border: any; 
  constructor(private el: ElementRef,private renderer: Renderer2) {
   console.log(this.color);
    this.changeBgColor(this.color);
   }

  //  @HostListener('click') onClick(){
  //    alert("hello");
  //  }
   @HostListener('mouseover') whenmouseenter(){
       this.changeBgColor(this.color);
      // this.border = '5px solid green';
   }

   @HostListener('mouseleave') whenmouseleave(){
      this.changeBgColor("black");
      this.border = "";
   }
   changeBgColor(color:string){
     this.renderer.setStyle(this.el.nativeElement,'color',color);
   }
  

}
