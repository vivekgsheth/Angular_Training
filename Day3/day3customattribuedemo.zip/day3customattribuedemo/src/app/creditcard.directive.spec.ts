import { CreditcardDirective } from './creditcard.directive';

describe('CreditcardDirective', () => {
  it('should create an instance', () => {
    const directive = new CreditcardDirective();
    expect(directive).toBeTruthy();
  });
});
