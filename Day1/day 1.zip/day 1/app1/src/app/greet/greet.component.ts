import { Component, OnInit } from '@angular/core';
import { IProduct } from '../IProduct';

@Component({
  selector: 'app-greet',
  templateUrl: './greet.component.html',
  styleUrls: ['./greet.component.css']
})
export class GreetComponent implements OnInit {

  message = "Greet World"; // coming from an API 
  height = 100; 
  width = 100; 
  products = []; 
  stext ='';

  constructor() { }

  ngOnInit(): void {
    this.products = this.getProducts();
  }

  getData(){
  this.height = 100; 
  }
  changeDate(){
    console.log('code to change date');
  }
  getProducts() : any {

    return [
      {
        "productId": 1,
        "productName": "Leaf Rake",


      },
      {
        "productId": 2,
        "productName": "Garden Cart",
       
      },
      {
        "productId": 5,
        "productName": "Hammer",
   
      },
      {
        "productId": 8,
        "productName": "Saw",

      },
      {
        "productId": 10,
        "productName": "Video Game Controller",
      
      },
      {
        "productId": 11,
        "productName": "Mobile  Game Controller",
        
      }
    ]
   
  }

}
