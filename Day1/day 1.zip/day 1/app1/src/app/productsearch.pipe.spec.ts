import { ProductsearchPipe } from './productsearch.pipe';

describe('ProductsearchPipe', () => {
  it('create an instance', () => {
    const pipe = new ProductsearchPipe();
    expect(pipe).toBeTruthy();
  });
});
