import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { GreetComponent } from './greet/greet.component';
import { MyAppRoutingModule } from './myapp-routing.module';
import { FormsModule } from '@angular/forms';
import { ProductsearchPipe } from './productsearch.pipe';
import { FooComponent } from './foo.component';

@NgModule({
  declarations: [
    AppComponent,
    GreetComponent,
    ProductsearchPipe,
    FooComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MyAppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
